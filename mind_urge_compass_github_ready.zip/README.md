# Adrian's Mind & Urge Compass

This folder is ready for GitHub Pages.

## Publish
1. Create a new public GitHub repository.
2. Upload `index.html` to the top level of the repository.
3. Open repository Settings.
4. Open Pages.
5. Under Build and deployment, choose:
   - Source: Deploy from a branch
   - Branch: main
   - Folder: /(root)
6. Save.
7. Wait for GitHub to display the published website address.

The app stores entries in the browser on the device where it is used.
